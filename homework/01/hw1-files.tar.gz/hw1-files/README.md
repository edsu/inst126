These are test files for use in Homework 1.

* allahabad-sangam.jpg: https://commons.wikimedia.org/wiki/File:Allahabad_sangam_with_siberian_in_winter.jpg
* bank-myna.jpg: https://commons.wikimedia.org/wiki/File:3485c_myna,bank_bithur_2007may05_09.46.54.jpg
* egyptian-vulture.jpg: https://commons.wikimedia.org/wiki/File:Egyptian_Vulture_(14657220504).jpg
* pied-kingfisher.jpg: https://commons.wikimedia.org/wiki/File:Pied_kingfisher_(Ceryle_rudis_leucomelanurus)_female.jpg

All files are available from Wikipedia using the CC-BY License.





